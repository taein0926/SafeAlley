"""Application configuration."""

