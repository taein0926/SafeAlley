from datetime import time
from typing import Literal

from pydantic import BaseModel, Field, field_validator


class CoordinateInput(BaseModel):
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)


class RouteRequest(BaseModel):
    start: CoordinateInput
    end: CoordinateInput
    source: str | None = Field(default=None, min_length=1, max_length=32)
    stairs_weight: float = Field(default=0.0, ge=0.0, le=1.0)
    intersection_weight: float = Field(default=0.0, ge=0.0, le=1.0)
    departure_time: time | None = None

    @field_validator("departure_time")
    @classmethod
    def local_departure_time(cls, value: time | None) -> time | None:
        if value is not None and value.tzinfo is not None:
            raise ValueError("departure_time must be a local Korean time without a timezone")
        return value


class GeoJSONLineString(BaseModel):
    type: Literal["LineString"]
    coordinates: list[list[float]]


class RouteRoadSegment(BaseModel):
    id: int
    source_id: str
    name: str | None
    from_node_id: int
    to_node_id: int
    distance_m: float
    streetlight_score: float
    cctv_score: float
    help_point_score: float = 0.0
    population_score: float
    safety_score: float
    coordinates: list[list[float]]
    highway: str | None = None
    step_count: str | None = None
    incline: str | None = None
    ramp: str | None = None
    wheelchair: str | None = None
    handrail: str | None = None
    streetlight_data_available: bool = True
    walkability_factor: float = 1.0
    crossing_node_ids: list[int] = Field(default_factory=list)
    is_steps: bool = False
    sidewalk_confirmed: bool = False
    incline_percent: float | None = None
    walkability_class: str | None = None
    distance_factor: float
    risk_factor: float
    stairs_penalty: float = 0.0
    crossing_group: int | None = None
    crossing_penalty: float = 0.0
    pedestrian_penalty: float = 0.0
    centreline_fallback: bool = False
    intersection_penalty: float = 0.0
    intersection_exposure_m: float = 0.0
    grade_separated: bool = False
    pedestrian_bridge_ids: list[str] = Field(default_factory=list)
    traversal_cost: float


class RouteCostWeights(BaseModel):
    distance: float
    risk: float
    stairs: float = 0.0
    intersection: float = 0.0
    crossing: float = 0.0


class RouteProperties(BaseModel):
    route_type: Literal["shortest", "balanced", "safe", "custom"]
    crs: Literal["EPSG:4326"]
    total_distance: float
    total_distance_m: float
    average_safety_score: float | None
    total_cost: float
    streetlight_included: bool = True
    stairs_segment_count: int = 0
    cost_weights: RouteCostWeights
    start_node_id: int
    end_node_id: int
    start_snap_distance_m: float
    end_snap_distance_m: float
    total_crosswalk_count: int = 0
    crossing_data_available: bool = False
    pedestrian_metadata_coverage_percent: float = 0.0
    centreline_fallback_distance_m: float = 0.0
    nonpreferred_walking_distance_m: float = Field(default=0.0, ge=0)
    crossing_baseline_distance_m: float | None = None
    crossing_distance_limit_m: float | None = None
    crossing_detour_limited: bool = False
    stairs_distance_m: float = 0
    intersection_distance_m: float = 0
    pedestrian_bridge_count: int = 0
    intersection_data_available: bool = False
    intersection_baseline_distance_m: float | None = None
    intersection_distance_limit_m: float | None = None
    intersection_detour_limited: bool = False
    sidewalk_coverage_percent: float = 0
    max_slope_percent: float | None = None
    slope_coverage_percent: float = 0
    road_segments: list[RouteRoadSegment]


class RouteFeature(BaseModel):
    type: Literal["Feature"]
    geometry: GeoJSONLineString
    properties: RouteProperties
