from dataclasses import dataclass
from datetime import time
from typing import Literal

from app.core.config import get_settings
from app.repositories.road_repository import (
    NearestRoadNode,
    RoutingRoadSegment,
    find_nearest_road_node,
    list_routing_road_segments,
)

from app.services.routing.astar import PathNotFoundError, PathResult, find_path
from app.services.routing.pedestrian_priority import find_pedestrian_first_path, nonpreferred_distance
from app.services.routing.graph import GraphEdge, GraphNode, RoadGraph
from app.services.routing.safety_cost import SafetyCostPolicy
from app.services.routing.intersection import find_intersection_aware_path
from app.services.weather_service import RouteTimeContext, resolve_route_time


class RoutingDataNotFoundError(RuntimeError):
    """Raised when the database has no usable road graph."""


class SnapDistanceExceededError(RuntimeError):
    """Raised when a requested point is too far from the road graph."""


class RouteNotFoundError(RuntimeError):
    """Raised when the snapped graph nodes are disconnected."""


def _build_graph(segments: list[RoutingRoadSegment]) -> RoadGraph:
    graph = RoadGraph()

    for segment in segments:
        graph.add_node(
            GraphNode(
                id=segment.source_node_id,
                x=segment.source_x,
                y=segment.source_y,
            )
        )
        graph.add_node(
            GraphNode(
                id=segment.target_node_id,
                x=segment.target_x,
                y=segment.target_y,
            )
        )

        if segment.forward_allowed:
            graph.add_edge(
                GraphEdge(
                    segment_id=segment.id,
                    source_id=segment.source_id,
                    name=segment.name,
                    from_node_id=segment.source_node_id,
                    to_node_id=segment.target_node_id,
                    distance_m=segment.length_m,
                    streetlight_score=segment.streetlight_score,
                    cctv_score=segment.cctv_score,
                    help_point_score=segment.help_point_score,
                    population_score=segment.population_score,
                    safety_score=segment.safety_score,
                    streetlight_data_available=segment.streetlight_data_available,
                    walkability_factor=segment.walkability_factor,
                    crossing_node_ids=segment.crossing_node_ids,
                    sidewalk_confirmed=segment.sidewalk_confirmed,
                    crossing_group=segment.crossing_group,
                    crossing_cost_units=segment.crossing_cost_units,
                    pedestrian_version=segment.pedestrian_version,
                    centreline_fallback=segment.centreline_fallback,
                    incline_percent=segment.incline_percent,
                    walkability_class=segment.walkability_class,
                    field_status=segment.field_status,
                    coordinates=segment.coordinates,
                    intersection_exposure_m=segment.intersection_exposure_m,
                    grade_separated=segment.grade_separated,
                    pedestrian_bridge_ids=segment.pedestrian_bridge_ids,
                    pedestrian_reference_version=segment.pedestrian_reference_version,
                    highway=segment.highway,
                    is_steps=segment.is_steps,
                    step_count=segment.step_count,
                    incline=segment.incline,
                    ramp=segment.ramp,
                    wheelchair=segment.wheelchair,
                    handrail=segment.handrail,
                )
            )
        if segment.reverse_allowed:
            graph.add_edge(
                GraphEdge(
                    segment_id=segment.id,
                    source_id=segment.source_id,
                    name=segment.name,
                    from_node_id=segment.target_node_id,
                    to_node_id=segment.source_node_id,
                    distance_m=segment.length_m,
                    streetlight_score=segment.streetlight_score,
                    cctv_score=segment.cctv_score,
                    help_point_score=segment.help_point_score,
                    population_score=segment.population_score,
                    safety_score=segment.safety_score,
                    streetlight_data_available=segment.streetlight_data_available,
                    walkability_factor=segment.walkability_factor,
                    crossing_node_ids=segment.crossing_node_ids,
                    sidewalk_confirmed=segment.sidewalk_confirmed,
                    crossing_group=segment.crossing_group,
                    crossing_cost_units=segment.crossing_cost_units,
                    pedestrian_version=segment.pedestrian_version,
                    centreline_fallback=segment.centreline_fallback,
                    incline_percent=segment.incline_percent,
                    walkability_class=segment.walkability_class,
                    field_status=segment.field_status,
                    coordinates=tuple(reversed(segment.coordinates)),
                    intersection_exposure_m=segment.intersection_exposure_m,
                    grade_separated=segment.grade_separated,
                    pedestrian_bridge_ids=segment.pedestrian_bridge_ids,
                    pedestrian_reference_version=segment.pedestrian_reference_version,
                    highway=segment.highway,
                    is_steps=segment.is_steps,
                    step_count=segment.step_count,
                    incline=segment.incline,
                    ramp=segment.ramp,
                    wheelchair=segment.wheelchair,
                    handrail=segment.handrail,
                )
            )

    return graph


def _validate_snap_distance(node: NearestRoadNode, point_name: str) -> None:
    maximum = get_settings().route_snap_max_distance_m
    if node.distance_m > maximum:
        raise SnapDistanceExceededError(
            f"{point_name} is {node.distance_m:.1f} m from the road graph; "
            f"maximum is {maximum:.1f} m"
        )


def _merge_path_coordinates(
    edges: tuple[GraphEdge, ...],
    start_node: NearestRoadNode,
) -> list[list[float]]:
    if not edges:
        point = [start_node.longitude, start_node.latitude]
        return [point, point.copy()]

    coordinates: list[list[float]] = []
    for edge in edges:
        for coordinate in edge.coordinates:
            point = [coordinate[0], coordinate[1]]
            if not coordinates or coordinates[-1] != point:
                coordinates.append(point)
    return coordinates


def _average_safety_score(result: PathResult, policy: SafetyCostPolicy) -> float | None:
    if result.total_distance_m == 0:
        return None
    weighted_total = sum(
        policy.effective_safety_score(edge) * edge.distance_m for edge in result.edges
    )
    return weighted_total / result.total_distance_m


def _route_feature(
    result: PathResult,
    start_node: NearestRoadNode,
    end_node: NearestRoadNode,
    route_type: Literal["shortest", "balanced", "safe", "custom"],
    policy: SafetyCostPolicy,
) -> dict[str, object]:
    average_safety_score = _average_safety_score(result, policy)
    crossing_node_ids = {
        node_id for edge in result.edges for node_id in edge.crossing_node_ids
    }
    crossing_groups = {edge.crossing_group for edge in result.edges if edge.crossing_group is not None}
    has_pedestrian_metadata = any(edge.pedestrian_version for edge in result.edges)
    stairs_distance_m = sum(
        edge.distance_m for edge in result.edges if edge.is_steps
    )
    sidewalk_distance_m = sum(
        edge.distance_m for edge in result.edges if edge.sidewalk_confirmed
    )
    explicit_slopes = [
        edge.incline_percent
        for edge in result.edges
        if edge.incline_percent is not None
    ]
    known_slope_distance_m = sum(
        edge.distance_m for edge in result.edges if edge.incline_percent is not None
    )
    unverified_major_road_ids = sorted({
        edge.source_id for edge in result.edges
        if edge.walkability_class == "major_road_fallback"
        and edge.field_status != "verified_walkable"
    })
    return {
        "type": "Feature",
        "geometry": {
            "type": "LineString",
            "coordinates": _merge_path_coordinates(result.edges, start_node),
        },
        "properties": {
            "route_type": route_type,
            "crs": "EPSG:4326",
            "total_distance": round(result.total_distance_m, 2),
            "total_distance_m": round(result.total_distance_m, 2),
            "average_safety_score": (
                round(average_safety_score, 2)
                if average_safety_score is not None
                else None
            ),
            "total_cost": round(result.total_cost, 2),
            "streetlight_included": policy.streetlight_included,
            "stairs_segment_count": sum(edge.is_steps for edge in result.edges),
            "cost_weights": {
                "distance": policy.distance_weight,
                "risk": policy.risk_weight,
                "stairs": policy.stairs_weight,
                "intersection": policy.intersection_weight,
                "crossing": policy.crossing_weight,
            },
            "start_node_id": start_node.node_id,
            "end_node_id": end_node.node_id,
            "start_snap_distance_m": round(start_node.distance_m, 2),
            "end_snap_distance_m": round(end_node.distance_m, 2),
            "total_crosswalk_count": len(crossing_groups) if has_pedestrian_metadata else len(crossing_node_ids),
            "crossing_data_available": bool(result.edges) and all(edge.pedestrian_version and not edge.centreline_fallback for edge in result.edges),
            "centreline_fallback_distance_m": round(sum(edge.distance_m for edge in result.edges if edge.centreline_fallback), 2),
            "pedestrian_metadata_coverage_percent": round(sum(edge.distance_m for edge in result.edges if edge.pedestrian_version) / result.total_distance_m * 100, 2) if result.total_distance_m else 0.0,
            "stairs_distance_m": round(stairs_distance_m, 2),
            "intersection_distance_m": round(sum(
                min(edge.distance_m, max(0.0, edge.intersection_exposure_m))
                for edge in result.edges if not edge.grade_separated
            ), 2),
            "pedestrian_bridge_count": len({
                identity for edge in result.edges for identity in edge.pedestrian_bridge_ids
            }),
            "sidewalk_coverage_percent": round(
                sidewalk_distance_m / result.total_distance_m * 100, 2
            ) if result.total_distance_m else 0.0,
            "slope_coverage_percent": round(
                known_slope_distance_m / result.total_distance_m * 100, 2
            ) if result.total_distance_m else 0.0,
            # Internal candidate selection only; omitted by the API response schema.
            "unverified_major_road_count": len(unverified_major_road_ids),
            # A partial DEM must not silently imply the unmeasured route is flat.
            "max_slope_percent": (
                round(max(explicit_slopes), 2)
                if explicit_slopes and len(explicit_slopes) == len(result.edges)
                else None
            ),
            "road_segments": [
                {
                    "id": edge.segment_id,
                    "source_id": edge.source_id,
                    "name": edge.name,
                    "from_node_id": edge.from_node_id,
                    "to_node_id": edge.to_node_id,
                    "distance_m": round(edge.distance_m, 2),
                    "streetlight_score": round(edge.streetlight_score, 2),
                    "cctv_score": round(edge.cctv_score, 2),
                    "help_point_score": round(edge.help_point_score, 2),
                    "population_score": round(edge.population_score, 2),
                    "safety_score": round(policy.effective_safety_score(edge), 2),
                    "coordinates": [list(coordinate) for coordinate in edge.coordinates],
                    "highway": edge.highway,
                    "is_steps": edge.is_steps,
                    "intersection_exposure_m": round(edge.intersection_exposure_m, 2),
                    "grade_separated": edge.grade_separated,
                    "pedestrian_bridge_ids": list(edge.pedestrian_bridge_ids),
                    "intersection_penalty": round(policy.breakdown(edge).intersection_penalty, 2),
                    "step_count": edge.step_count,
                    "incline": edge.incline,
                    "ramp": edge.ramp,
                    "wheelchair": edge.wheelchair,
                    "handrail": edge.handrail,
                    "streetlight_data_available": edge.streetlight_data_available,
                    "walkability_factor": edge.walkability_factor,
                    "crossing_node_ids": list(edge.crossing_node_ids),
                    "crossing_group": edge.crossing_group,
                    "centreline_fallback": edge.centreline_fallback,
                    "pedestrian_penalty": round(policy.breakdown(edge).pedestrian_penalty, 2),
                    "crossing_penalty": round(policy.breakdown(edge).crossing_penalty, 2),
                    "sidewalk_confirmed": edge.sidewalk_confirmed,
                    "incline_percent": edge.incline_percent,
                    "walkability_class": edge.walkability_class,
                    "field_status": edge.field_status,
                    "distance_factor": round(
                        policy.breakdown(edge).distance_factor,
                        2,
                    ),
                    "risk_factor": round(policy.breakdown(edge).risk_factor, 2),
                    "stairs_penalty": round(
                        policy.breakdown(edge).stairs_penalty,
                        2,
                    ),
                    "traversal_cost": round(
                        policy.edge_cost(edge)
                        + (0.0 if route_type in {"shortest", "custom"} else edge.distance_m * max(0.0, edge.walkability_factor - 1.0)),
                        2,
                    ),
                }
                for edge in result.edges
            ],
        },
    }


@dataclass(frozen=True)
class PreparedRoute:
    """Read-only graph and snapped endpoints, shared only within one search."""

    graph: RoadGraph
    start_node: NearestRoadNode
    end_node: NearestRoadNode
    intersection_data_available: bool


def get_custom_route(*, prepared, preferences, stairs_weight=0.0, crossing_weight=0.0,
                     time_context, **_):
    from app.services.routing.custom import custom_policy, find_custom_path
    policy = custom_policy(preferences, stairs_weight=stairs_weight,
                           crossing_weight=crossing_weight, is_night=time_context.is_night,
                           settings=get_settings())
    try:
        result, baseline, limit, limited = find_custom_path(
            prepared.graph, prepared.start_node.node_id, prepared.end_node.node_id, policy, preferences,
        )
    except PathNotFoundError as exc:
        raise RouteNotFoundError(str(exc)) from exc
    feature = _route_feature(result, prepared.start_node, prepared.end_node, "custom", policy)
    feature["properties"].update(
        intersection_data_available=prepared.intersection_data_available,
        nonpreferred_walking_distance_m=round(nonpreferred_distance(result.edges), 3),
        crossing_baseline_distance_m=round(baseline, 2),
        crossing_distance_limit_m=round(limit, 2), crossing_detour_limited=limited,
    )
    return feature


def prepare_route(
    start_longitude: float,
    start_latitude: float,
    end_longitude: float,
    end_latitude: float,
    source: str | None = None,
) -> PreparedRoute:
    start_node = find_nearest_road_node(
        start_longitude,
        start_latitude,
        source=source,
    )
    end_node = find_nearest_road_node(
        end_longitude,
        end_latitude,
        source=source,
    )
    if start_node is None or end_node is None:
        raise RoutingDataNotFoundError("The road graph is empty")

    _validate_snap_distance(start_node, "start")
    _validate_snap_distance(end_node, "end")

    segments = list_routing_road_segments(source=source)
    if not segments:
        raise RoutingDataNotFoundError("The road graph is empty")

    graph = _build_graph(segments)
    if any(segment.pedestrian_version for segment in segments):
        from app.services.routing.snapping import connected_node_pair
        try:
            find_path(graph, start_node.node_id, end_node.node_id, lambda e: e.distance_m, 1)
        except PathNotFoundError:
            try:
                pair = connected_node_pair(
                    graph, (start_longitude, start_latitude), (end_longitude, end_latitude),
                    get_settings().route_snap_max_distance_m,
                )
            except PathNotFoundError as exc:
                raise RouteNotFoundError(str(exc)) from exc
            start_node, end_node = [
                NearestRoadNode(node, graph.nodes[node].x, graph.nodes[node].y,
                                coordinate[0], coordinate[1], distance)
                for node, coordinate, distance in pair
            ]
    return PreparedRoute(
        graph=graph, start_node=start_node, end_node=end_node,
        intersection_data_available=any(
            segment.pedestrian_reference_version == "pedestrian-reference-v1"
            for segment in segments
        ),
    )


def _get_route(
    start_longitude: float,
    start_latitude: float,
    end_longitude: float,
    end_latitude: float,
    route_type: Literal["shortest", "balanced", "safe", "custom"],
    source: str | None = None,
    stairs_weight: float = 0.0,
    penalized_segment_ids: set[int] | None = None,
    intersection_weight: float = 0.0,
    prepared: PreparedRoute | None = None,
    departure_time: time | None = None,
    time_context: RouteTimeContext | None = None,
) -> dict[str, object]:
    time_context = time_context or resolve_route_time(departure_time)
    context = prepared or prepare_route(
        start_longitude, start_latitude, end_longitude, end_latitude, source,
    )
    graph, start_node, end_node = context.graph, context.start_node, context.end_node
    settings = get_settings()
    if route_type == "shortest":
        policy = SafetyCostPolicy(
            distance_weight=1.0,
            risk_weight=0.0,
            stairs_weight=stairs_weight,
        )
    elif route_type == "balanced":
        policy = SafetyCostPolicy(
            distance_weight=settings.safe_route_distance_weight,
            risk_weight=settings.safe_route_risk_weight / 2,
            stairs_weight=stairs_weight,
        )
    else:
        policy = SafetyCostPolicy(
            distance_weight=settings.safe_route_distance_weight,
            risk_weight=settings.safe_route_risk_weight,
            stairs_weight=stairs_weight,
        )
    # Diversification penalties must not inflate the avoidance baseline/cap.
    penalized_segment_ids = (penalized_segment_ids or set()) if intersection_weight == 0 else set()
    policy = SafetyCostPolicy(
        distance_weight=policy.distance_weight, risk_weight=policy.risk_weight,
        stairs_weight=stairs_weight, intersection_weight=intersection_weight,
        streetlight_included=time_context.is_night,
        cctv_weight=settings.safety_cctv_weight,
        help_point_weight=settings.safety_help_point_weight,
    )

    def extra_cost(edge: GraphEdge) -> float:
        return 0.0 if route_type == "shortest" else edge.distance_m * max(0.0, edge.walkability_factor - 1.0)

    def route_cost(edge: GraphEdge) -> float:
        base_cost = (
            policy.edge_cost(edge)
            + extra_cost(edge)
        )
        if edge.segment_id in penalized_segment_ids:
            return base_cost + edge.distance_m * 10
        return base_cost

    try:
        bounded = None
        if intersection_weight > 0:
            bounded = find_intersection_aware_path(
                graph, start_node.node_id, end_node.node_id, policy, extra_cost,
            )
            result = bounded.path
        else:
            result = find_pedestrian_first_path(
                graph=graph,
                start_node_id=start_node.node_id,
                goal_node_id=end_node.node_id,
                edge_cost=route_cost,
                minimum_cost_per_meter=policy.distance_weight,
            )
    except PathNotFoundError as exc:
        raise RouteNotFoundError(str(exc)) from exc

    feature = _route_feature(result, start_node, end_node, route_type, policy)
    feature["properties"]["nonpreferred_walking_distance_m"] = round(nonpreferred_distance(result.edges), 3)
    feature["properties"]["intersection_data_available"] = context.intersection_data_available
    if bounded is not None:
        feature["properties"].update({
            "intersection_baseline_distance_m": round(bounded.baseline_distance_m, 2),
            "intersection_distance_limit_m": round(bounded.distance_limit_m, 2),
            "intersection_detour_limited": bounded.detour_limited,
        })
    return feature


def get_shortest_route(
    start_longitude: float,
    start_latitude: float,
    end_longitude: float,
    end_latitude: float,
    source: str | None = None,
    stairs_weight: float = 0.0,
    intersection_weight: float = 0.0,
    prepared: PreparedRoute | None = None,
    departure_time: time | None = None,
    time_context: RouteTimeContext | None = None,
) -> dict[str, object]:
    return _get_route(
        start_longitude,
        start_latitude,
        end_longitude,
        end_latitude,
        route_type="shortest",
        departure_time=departure_time,
        time_context=time_context,
        prepared=prepared,
        source=source,
        stairs_weight=stairs_weight,
        intersection_weight=intersection_weight,
    )


def get_safe_route(
    start_longitude: float,
    start_latitude: float,
    end_longitude: float,
    end_latitude: float,
    source: str | None = None,
    stairs_weight: float = 0.0,
    intersection_weight: float = 0.0,
    prepared: PreparedRoute | None = None,
    departure_time: time | None = None,
    time_context: RouteTimeContext | None = None,
) -> dict[str, object]:
    return _get_route(
        start_longitude,
        start_latitude,
        end_longitude,
        end_latitude,
        route_type="safe",
        departure_time=departure_time,
        time_context=time_context,
        prepared=prepared,
        source=source,
        stairs_weight=stairs_weight,
        intersection_weight=intersection_weight,
    )


def get_balanced_route(
    start_longitude: float,
    start_latitude: float,
    end_longitude: float,
    end_latitude: float,
    source: str | None = None,
    stairs_weight: float = 0.0,
    penalized_segment_ids: set[int] | None = None,
    intersection_weight: float = 0.0,
    prepared: PreparedRoute | None = None,
    departure_time: time | None = None,
    time_context: RouteTimeContext | None = None,
) -> dict[str, object]:
    return _get_route(
        start_longitude,
        start_latitude,
        end_longitude,
        end_latitude,
        route_type="balanced",
        departure_time=departure_time,
        time_context=time_context,
        prepared=prepared,
        source=source,
        stairs_weight=stairs_weight,
        penalized_segment_ids=penalized_segment_ids,
        intersection_weight=intersection_weight,
    )
