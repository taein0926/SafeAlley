"""SafeAlley FastAPI application."""

