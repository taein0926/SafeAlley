"""External raw data collectors."""
